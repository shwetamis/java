package com.fannie.io;

import java.io.Serializable;

public class Customer implements Serializable { // this is eligible to become serilizable
	
	private int custID;
	private String custName;
	
	
	@Override
	public String toString() {
		return "Customer [custID=" + custID + ", custName=" + custName + "]";
	}
	public int getCustID() {
		return custID;
	}
	public void setCustID(int custID) {
		this.custID = custID;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	

}
