package com.fannie.io;

import java.io.File;
import java.io.IOException;

public class FileExample {
public static void main(String[] args) throws IOException {
	File f =new File("sample.txt");

		//System.out.println(f.createNewFile());
		//System.out.println(f.delete());
		System.out.println(f.getAbsolutePath());
		System.out.println(f.getPath());
   System.out.println(f.getTotalSpace());
   System.out.println(f.canRead());
   System.out.println("can write" +f.canWrite());
   System.out.println(f.isFile());
   System.out.println(f.isDirectory());
}
	
}
