package com.fannie.io;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class WriteToFile {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int empID;
		String empName;
		double empSal;
		
		System.out.println("Enter emp ID");
		empID=Integer.parseInt(br.readLine()); // br.readline is from string family and empid is number so you have to wrap it with integer.parseint
		
		System.out.println("Enter EMP Name");
		empName=br.readLine();
		
		System.out.println("Enter emp sal");
		empSal= Double.parseDouble(br.readLine());
		
		BufferedWriter bw = new BufferedWriter( new FileWriter ("shweta.txt",true));// when we write in buffer writer file writer takes to file.txt// with true file will be in append mode
	
		bw.write(new Integer(empID).toString());// if we don't use the wrapper then it will be converted to char (autoboxing)
		bw.write(empName);
		bw.write(new Double(empSal).toString());// for double you need a wrapper class as its not in option. wrapper class are for conversions
		bw.newLine();//this put line breaks
		bw.close();// without that below print statement won't work
		
		System.out.println( "Data written");
		
		
	}
}
