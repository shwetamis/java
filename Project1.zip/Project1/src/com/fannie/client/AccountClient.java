package com.fannie.client;

import com.fannie.beans.Account;
import com.fannie.dao.AccountDao;
import com.fannie.interfaces.IAccountDAO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class AccountClient {

	public static void main(String[] args) throws NumberFormatException, IOException {
		IAccountDAO dao = new AccountDao();
		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		 /* ArrayList columnNames = new ArrayList();
	        ArrayList data = new ArrayList();*/
		// Account acc = new Account();
		/*
		 * System.out.println("Enter amount percent"); percent=
		 * Float.parseFloat(br.readLine());
		 */

		// insert
		//System.out.println( dao.insertBatchAccount());
		
		//Update based on %	
		//dao.getAllAccs();


		//Return all Accounts
		for (Account temp: dao.getAllAccs() ){
			 System.out.println(temp);
		 }
		// select Based on Account ID

		//	System.out.println(dao.getAcc(2));
		// System.out.println("Account selected for : " +dao.getAcc(2));
		
	
	}

}
