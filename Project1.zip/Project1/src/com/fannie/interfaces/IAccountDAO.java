package com.fannie.interfaces;
import java.util.List;
import com.fannie.beans.Account;


public interface IAccountDAO {
	public boolean insertaccount(Account acc);
	public List<Account> getAllAccs();
	public Account getAcc(int ID);
	public boolean updateAcc(int ID, double AvgBal);
	public boolean deleteAcc(int ID);
	
	
	public boolean insertBatchAccount();
}
