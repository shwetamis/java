package com.fannie.beans;

import java.io.Serializable;

public class Account implements Serializable  {
	private int ID;
	private int Account_No;
	private double Balance;
	private double Average_Balance;
	private double percent;
	
	@Override
	public String toString() {
		return "Account [ID=" + ID + ", Account_No=" + Account_No + ", Balance=" + Balance + ", Average_Balance="
				+ Average_Balance + "]";
	}
	public Account() {
	}
	
	public Account(int ID,int Account_No,double Balance,double Average_Balance){
		super();
		this.ID =ID;
		this.Account_No= Account_No;
		this.Balance = Balance;
		this.Average_Balance=Average_Balance;
		
	}
	
	public Account(int Account_No,double Balance,double Average_Balance){
		this.Account_No= Account_No;
		this.Balance = Balance;
		this.Average_Balance=Average_Balance;
		
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getAccount_No() {
		return Account_No;
	}
	public void setAccount_No(int account_No) {
		Account_No = account_No;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public double getAverage_Balance() {
		return Average_Balance;
	}
	public void setAverage_Balance(double average_Balance) {
		Average_Balance = average_Balance;
	}
	
}
