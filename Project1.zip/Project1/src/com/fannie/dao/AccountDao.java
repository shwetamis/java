package com.fannie.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.fannie.beans.Account;
import com.fannie.connection.GetConnection;
import com.fannie.interfaces.IAccountDAO;

public class AccountDao implements IAccountDAO {

	public boolean insertBatchAccount() {

		Account obj1 = new Account(374, 19999, 28);
		// Account obj2 = new Account(56, 55533,666);
		// Account obj3 = new Account(88, 33335,233);
		// Account obj4 = new Account(55, 42111,888);

		String sql = "insert into account ( Account_No, Balance,Average_Balance ) values(?,?,?)";

		GetConnection gc = new GetConnection();
		System.out.println(" connected to the db" + gc);
		try {
			//gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			System.out.println(" connected to the db" + sql);
			// gc.ps.setInt(1, obj1.getID());
			gc.ps.setInt(1, obj1.getAccount_No());
			gc.ps.setDouble(2, obj1.getBalance());
			gc.ps.setDouble(3, obj1.getAverage_Balance());

			gc.ps.addBatch();
			/*
			 * //gc.ps.setInt(1, obj1.getID()); gc.ps.setInt(1,
			 * obj2.getAccount_No()); gc.ps.setDouble(2, obj2.getBalance());
			 * gc.ps.setDouble(3, obj2.getAverage_Balance());
			 * 
			 * gc.ps.addBatch(); //gc.ps.setInt(1, obj1.getID());
			 * gc.ps.setInt(1, obj3.getAccount_No()); gc.ps.setDouble(2,
			 * obj3.getBalance()); gc.ps.setDouble(3,
			 * obj3.getAverage_Balance());
			 * 
			 * gc.ps.addBatch(); //gc.ps.setInt(1, obj1.getID());
			 * gc.ps.setInt(1, obj4.getAccount_No()); gc.ps.setDouble(2,
			 * obj4.getBalance()); gc.ps.setDouble(3,
			 * obj4.getAverage_Balance());
			 * 
			 * 
			 * gc.ps.addBatch();
			 */
			return gc.ps.executeBatch().length > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;

	}

	@Override
	public boolean insertaccount(Account acc) {
		String sql = "insert into account (Account_No, Balance,Average_Balance) values(?,?,?)";

		try {
			GetConnection gc = new GetConnection();
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql); // connection
																	// object
			// gc.ps.setInt(1, acc.getID());
			gc.ps.setInt(1, acc.getAccount_No()); // prepared statements
			gc.ps.setDouble(2, acc.getBalance());
			gc.ps.setDouble(3, acc.getAverage_Balance());

			return gc.ps.executeUpdate() > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public List<Account> getAllAccs() {

		String sql = "select ID, Account_No, Balance,Average_Balance from account";
		List<Account> accs = new ArrayList<Account>();
		GetConnection gc = new GetConnection();

		try {
			GetConnection.mysqlCon().setAutoCommit(true);
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			gc.rs = gc.ps.executeQuery();
			for (; gc.rs.next();) {
				Account temp = new Account();
				temp.setID(gc.rs.getInt(1));
				temp.setAccount_No(gc.rs.getInt(2));
				temp.setBalance(gc.rs.getDouble(3));

				Scanner s = new Scanner(System.in);
				String str = s.nextLine();
				int perCount = Integer.parseInt(str);

				System.out.println("The current Avg Bal for this record is: " + gc.rs.getDouble(4));
				int ID = gc.rs.getInt(1);
				double AvgBal = (gc.rs.getDouble(4) * perCount) / 100; 

				System.out.println("The updated Avg Bal for this record now is: " + AvgBal);

				temp.setAverage_Balance(AvgBal);
				updateAcc(ID, AvgBal);
				accs.add(temp);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return accs;
	}

	@Override
	public Account getAcc(int ID) {
		String sql = "select ID, Account_No, Balance,Average_Balance from account where ID =2";
		GetConnection gc = new GetConnection();

		try {
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			gc.rs = gc.ps.executeQuery();
			for (; gc.rs.next();) {
				Account temp = new Account();
				temp.setID(gc.rs.getInt(1));
				temp.setAccount_No(gc.rs.getInt(2));
				temp.setBalance(gc.rs.getDouble(3));
				temp.setAverage_Balance(gc.rs.getDouble(3));

				return temp;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public boolean updateAcc(int ID, double AvgBal) {
		String sql = "update transaction set final_bal = ? where Acc_ID =?";
		GetConnection gc = new GetConnection();
		//System.out.println("Enter the % value to be updated for AvgBal: ");
		try {
			GetConnection.mysqlCon().setAutoCommit(true);
			System.out.println("commit executed");
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			System.out.println(sql);
			gc.ps.setInt(1, ID);
			gc.ps.setDouble(2, AvgBal);
			System.out.println(AvgBal);
			gc.ps.setInt(1, ID);
			System.out.println("Enter the % value to be updated for AvgBal: ");
			return gc.ps.executeUpdate() > 0;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deleteAcc(int ID) {
		String sql = "delete from account where ID=?";

		GetConnection gc = new GetConnection();
		try {
			// GetConnection.mysqlCon().setAutoCommit(false);
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			gc.ps.setInt(1, ID);

			return gc.ps.executeUpdate() > 0;

		} catch (SQLException e) {
			try {
				GetConnection.mysqlCon().rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				gc.ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return false;
	}


}
