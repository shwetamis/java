package com.fannie.interfaces;
import java.util.*;


public class EmployeeSortClient {
	public   static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp[] emps = {
			   new Emp(101,"Shweta",20000),
			   new Emp(100,"Deepak",30000),
			   new Emp(99,"Sri",40000),
			   new Emp(104,"Tosha",10000)
	};
	
System.out.println("Before sort");
			 for (Emp temp: emps) {
				 System.out.println(temp);
			 }
			// Arrays.sort(emps, new EmpSorter());// we passed the array and said that look for sorter in EMPsorter class
			 
			 //Comparator<Emp> mycompare= new Comparator<EMP>() -- this is abstract as its an interface all interfaces are abstract
			 Arrays.sort(emps, new Comparator<Emp>(){
//this is anonymus class and when doen't have method like empsorter this will sort in desc order based on name
				 //scope of anonymus interface is only for that block
				@Override
				public int compare(Emp o1, Emp o2) {
					// TODO Auto-generated method stub
					return o2.getEmpName().compareTo(o1.getEmpName());
					
				}
				 
			 });
			 System.out.println("--------");
			 
			 for (Emp temp: emps) {
				 System.out.println(temp);
			 }
	}
}