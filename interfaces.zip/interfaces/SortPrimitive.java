package com.fannie.interfaces;

import java.util.Arrays;

public class SortPrimitive {

	public   static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums =new int [7];
		
		nums[0]=10;
		nums[1]=11;
		nums[2]=100;
		nums[3]=101;
		nums[4]=111;
		nums[5]=132;
		nums[6]=143;
		
		System.out.println("Original list");
		System.out.println("------------------------------");
for(int i : nums){
			System.out.println(i);
			}

	System.out.println("Sorted list");
	System.out.println("################################");
		Arrays.sort(nums);
for(int i: nums){
	System.out.println(i);

   } //* for loop

   }
}

