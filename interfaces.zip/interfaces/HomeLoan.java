package com.fannie.interfaces;

public class HomeLoan implements Loan {
	int loanAmount;

	public HomeLoan(int loanAmount) {
		this.loanAmount = loanAmount;

	}

	@Override
	public void submitLoan() {
		// TODO Auto-generated method stub
		System.out.println(" Home loan submitted");

	}

	@Override
	public void loanAmount() {
		// TODO Auto-generated method stub
		System.out.println("Loan amount :" + loanAmount);
	}

	@Override
	public void forCLosure() {
		// TODO Auto-generated method stub
		System.out.println("Loan foreclosure applied");

	}

	@Override
	public void forClosure(int amount) {
		// TODO Auto-generated method stub
		System.out.println("Loan forclosure with :" + amount);

	}

}
