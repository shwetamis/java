package com.fannie.interfaces;

public class LoanClient {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// we will get error 
		Loan[] loans =new Loan[4]; //placeholder
		
		loans[0] =new HomeLoan(100);
		loans[1] =new PersonalLoan(1000);
		loans[2] =new HomeLoan(200);
		loans[3] =new  PersonalLoan(20000);
		
for (Loan temp : loans){
	System.out.println("........................");
	temp.loanAmount();
	temp.forCLosure();
	temp.submitLoan();
}
	}

}
