package com.fannie.interfaces;

public class PersonalLoan implements Loan {
	
int loanAmount;
public PersonalLoan(int loanAmount){
	this.loanAmount =loanAmount;
	
}
	@Override
	public void submitLoan() {
		// TODO Auto-generated method stub	
		System.out.println(" Personal loan submitted");
	}

	@Override
	public void loanAmount() {
		// TODO Auto-generated method stub
		System.out.println(" Personal loan amount" + loanAmount);		
	}

	@Override
	public void forCLosure() {
		// TODO Auto-generated method stub
		System.out.println(" Personal loan Foreclosure");
		
	}

	@Override
	public void forClosure(int amount) {
		// TODO Auto-generated method stub
		System.out.println(" Personal loan foreclosure amount" + amount);

	}

}
