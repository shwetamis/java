package com.fannie.interfaces;

public class Emp implements Comparable<Emp> {
	private int empID;
	private String empName;
	private double empSal;
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Emp [empID=" + empID + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	public Emp(int empID, String empName, double empSal) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.empSal = empSal;
	}
	@Override
	
	//comparable can only sort on 1 field
	//comparator can sort on multiple field so in case u want that use comparator interface
	
	//compare comes from java.lang and comparator comes from java.util
	public int compareTo(Emp o) {
		//return this.empID - o.getEmpID(); //comparing two value emmID on top VS empID of o
		//since empID is prim type we used minus
		
		//return this.empName.compareTo(o.getEmpName()); // is u want to sort by empname in asc order
		return o.getEmpName().compareTo(this.empName);// sort by desc order
		
	}


}
