package com.fannie.interfaces;
import java.util.*;

// from util we are using Comparator class

//this class is created for multiple sort as we want to sort on empname and sal
public class EmpSorter implements Comparator<Emp>{

	@Override
	public int compare(Emp o1, Emp o2) {
		// TODO Auto-generated method stub
		return (int) (o1.getEmpSal()-o2.getEmpSal());
	}

}
