package com.fannie.interfaces;
import java.util.*;

public class SortString {
	
	public   static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] strs = {"hello", "how", "are","you"};
		
		Arrays.sort(strs);
		for(String temp: strs){
			System.out.println(temp);
		}
	}	

}
