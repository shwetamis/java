package com.fannie.interfaces;

public interface Loan {
	void submitLoan();
	void loanAmount();// use immutable constant that is constructor, since it is fixed and should not be changed once submitted
	void forCLosure();
	void forClosure(int amount);
	

}
