package com.fannie.assignment1;

public class Bus extends Vehicle {

	Bus(String color){
		super (color);
		
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("::::::::::::::::::::::::::::");
		System.out.println( getColor() +" Bus is moving" );
		System.out.println("::::::::::::::::::::::::::::");
	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println( getColor() +" Bus stops" +" when brakes are applied");
		System.out.println("::::::::::::::::::::::::::::");
		
	}

	@Override
	public void speeding() {
		// TODO Auto-generated method stub
		System.out.println( getColor() +" Bus is  speeding");
	}
	
}
