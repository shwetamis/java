package com.fannie.assignment1;

public class Road {
 public void move(Vehicle v)
 {
	v.move();
 }
 public void brake(Vehicle v)
 {
	v.brake();
 }
 
 public void speeding(Vehicle v)
 {
	 v.speeding();
 }

}
