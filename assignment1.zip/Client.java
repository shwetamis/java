package com.fannie.assignment1;

public class Client {
public static void main(String[] args) {
	Vehicle [] vehicles = new Vehicle [6]; //5 block of memory created
	
	vehicles[0] =new Car ("BMW",4, true);
	vehicles[1] =new Car ("Toyota",4, true);
	vehicles[2] =new Truck ("Black","Merc");
	vehicles[3] =new Bus ("Red");
	vehicles[4] =new Car ("Honda",4, true);
	vehicles[5] =new Bus ("Yellow");

	Road road= new Road();
	for(Vehicle temp: vehicles){
		road.move(temp);
		road.brake(temp);
		road.speeding(temp);
	}
  }
}
