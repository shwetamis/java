package com.fannie.assignment1;

public abstract class Vehicle {
	private String color;
	private int wheels;
	private String make;

public Vehicle(String color) {
		super();
		this.color = color;	
	}
public Vehicle(String color, String make) {
	super();
	this.color = color;	
	this.make=make;
	
}
	public Vehicle(String color, int wheels, String make) {
		super();
		this.color = color;
		this.wheels = wheels;
		this.make = make;
	}

	public Vehicle(String make, int wheels) {
		super();
		this.wheels = wheels;
		this.make = make;
	}
	
	
	


	public abstract void move();

	public abstract void brake();

	public abstract void speeding();

	public String getColor() {
		return color;
	}

	public int getWheels() {
		return wheels;
	}

	public String getMake() {
		return make;
	}

}
