package com.fannie.assignment1;

public class Truck extends Vehicle  {
	
	Truck(String color, String make){
		super (color,make);
		
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("::::::::::::::::::::::::::::");
		System.out.println( getColor() + " " +getMake() + " Truck is moving");
		System.out.println("::::::::::::::::::::::::::::");
		
	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println( getColor() +" Truck stops" +" when brakes are applied");
		System.out.println("::::::::::::::::::::::::::::");
	}
	@Override
	public void speeding() {
		// TODO Auto-generated method stub
		System.out.println( getColor() +" Truck is  speeding");
	}
}
