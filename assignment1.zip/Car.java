package com.fannie.assignment1;

public class Car extends Vehicle{
	private boolean abs;
	public Car(String make, int wheels,boolean abs){
		super(make, wheels);
		this.abs=abs;
	}
	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("::::::::::::::::::::::::::::");
		System.out.println( getMake() +" Car is moving"  +" And has this car has : " +getWheels()+"  Wheels");
		System.out.println("::::::::::::::::::::::::::::");
	}
	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println( getMake() +" Car stops" +" when brakes are applied");
		System.out.println("::::::::::::::::::::::::::::");
	}
	@Override
	public void speeding() {
		// TODO Auto-generated method stub
		System.out.println( getMake() +" Car speeding");
	}

}
