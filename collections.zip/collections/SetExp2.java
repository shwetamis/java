package com.fannie.collections;

import java.util.HashSet;

class Device{
	private int Id;
	private String name;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Device(int id, String name) {
		super();
		Id = id;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Device [Id=" + Id + ", name=" + name + "]";
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		//return super.hashCode();
		return this.name.charAt(0) ; // in this class look at the name and take 0th position
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub// this method does the checking
		
		Device temp =(Device) obj; //
		return this.Id==temp.Id && this.name.equals(temp.getName()) ;
	}
	
	
}


public class SetExp2 {

	public static void main(String[] args) {
		
		HashSet<Device> devices = new HashSet<Device>();
		
		devices.add(new Device (101, "Laptop"));
		devices.add(new Device (12, "Computer"));
		devices.add(new Device (1051, "Projector"));
		devices.add(new Device (445, "Presentor"));
		
		devices.add(new Device (101, "Laptop")); // this will still display laptop twice that is not correct 
		
		for(Device temp : devices){
			//System.out.println(temp);
			System.out.println(temp +"," + temp.hashCode());
		}
				
		
	}
}
