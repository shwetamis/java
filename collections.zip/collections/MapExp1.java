package com.fannie.collections;

// inpot classes that are needed don't use all the classes in the package as it will slow down the performance
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapExp1 {

	public static void main(String[] args) {
		//map that has key that is string and value is integer
		Map <String , Integer> map =new HashMap<String , Integer>();
		// instead of add we have put
		map.put("Shweta", 10000);
		map.put("Tosha", 2000);
		map.put("Bharti", 20);
		map.put("Sri", 200);
	
		/*//System.out.println(map.get("Bharti")); // i will get val associated with bharti
		
		map.put("Bharti", 10);
		System.out.println(map.get("Bharti")); // it will override previous val it will never return false or rejects
		
		// map don't have iterate
*/   
		//set should be raw type, if you want to be flexible, if you do string it will only store string, raw can hold anything
		Set set =map.entrySet();// entry set is starting position
		Iterator itr =set.iterator(); // we don't do util .* as prog becomes heavy loaded
		
		while (itr.hasNext()) {
			Map.Entry<String, Integer> temp =
					(Entry<String, Integer>) itr.next();
			
			// F2 shows typecast or take mouse on top of it
			//data will be displayed as is its not sorted
			System.out.println(temp.getKey()+ "," +temp.getValue());
		}
		
	}
}