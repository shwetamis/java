package com.fannie.collections;

import java.util.HashSet;
import java.util.Set;

public class WildCardEx {

	// this method will show data from Int, num double , float, byte and short
	public static void display(Set<? extends Number> set){ // i will unknown datatype that extends number
		
		for (Number temp : set)
			System.out.println(temp);
		
	}
	
	
	public static void main(String[] args) {
		
		//Set<Number> set= new HashSet<Integer>(); // java doen't support polymorphism when comes to collection
		
		Set<Number> set;
		Set <Integer> iset= new HashSet<Integer>();
		
		iset.add(100);
		iset.add(200);	
		iset.add(400);
		iset.add(10);
		iset.add(30);
		
		display(iset);
		// add display method
		
		Set <Double> dset= new HashSet<Double>();
		
		dset.add(1000d);
		dset.add(200d);	
		dset.add(4000d);
		
		display(dset);
		// Add display method
		
	}
}
