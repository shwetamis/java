package com.fannie.collections;

import java.util.Vector;

public class ListEx4 {
//vector is good for pooling where capacity can increase
	public static void main(String[] args) {
		Vector<String> vec = new Vector <String>(5,3);// next jump will be 11+3
		
		System.out.println(" Initial Capacity " + vec.capacity());
		System.out.println(" Initial Size " + vec.size());
		
		vec.add("ONE");
		vec.add("TWO");
		vec.add("three");
		vec.add("four");
		vec.add("five");
		vec.add("six");
		vec.add("seven");
		vec.add("eight");
		vec.add("nine");
		vec.add("ten");
		vec.add("eleven");
		vec.add("twelve");
		
		System.out.println(" Initial Capacity " + vec.capacity());
		System.out.println(" Initial Size " + vec.size());
		
	}
	
}
