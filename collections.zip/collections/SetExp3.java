package com.fannie.collections;


import java.util.Set;
import java.util.TreeSet;

//working of treeset ( it comes from sorted set
public class SetExp3 {

	public static void main(String[] args) {
		
		//f4 gives hierarchy of class
	Set<String> set = new TreeSet<String>(); 
		// hash set is subset of set
		//auto sort
		set.add("Shweta");
		set.add("Diva");
		set.add("Riva");	
		set.add("Great");
		
		System.out.println(set);
		
	}
}
