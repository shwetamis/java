package com.fannie.collections;

import java.util.Stack;

public class ListEx3 {

	public static void main(String[] args) {
		Stack<String> stack = new Stack <String>();
		
		stack.push("Riva");
		stack.push("dave");
		stack.push("sri");
		
		System.out.println(stack);
		
		stack.push("Shweta");
		System.out.println(stack);
		
		stack.pop();
		System.out.println(stack);
		stack.pop();
		System.out.println(stack);
		System.out.println(stack.peek());//peek will not take element out it will only display
		
	}
}
