package com.fannie.abstracts;
//in abstract class you can have abstract methods

//polymorphism: same object behaving differently at diff point of time
public abstract class Figure {
public abstract void area();
public final double PI=3.1; // since value of PI is not changing in the circle thats why defined at parent level child is circle class


public void draw() {
	System.out.println(" can draw with pen and a pencil");
}

}