package com.fannie.abstracts;

public class Rectangle extends Figure {
	//public void rectArea() {}
	private int len;
	private int wid;
	

	public Rectangle(int len, int wid) {
		super();
		this.len = len;
		this.wid = wid;
	}


	@Override
	public void area() {
		// TODO Auto-generated method stub
		System.out.println(" Area is (lxw )"+ (len * wid));
	}	
	
}

