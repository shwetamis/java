package com.fannie.abstracts;

public class Circle extends Figure {
	private int radius;	
	
	public Circle(int radius) {
		super();
		this.radius= radius;
	}

	@Override
	public void area() {
		// TODO Auto-generated method stub
		System.out.println(" Area of circle");
	}

	

}

