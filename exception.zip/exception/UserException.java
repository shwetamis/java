package com.fannie.exception;

// by extending the class from exception it becomes eligible to throw
class FannieException extends Exception {
	private String msg;
	
	FannieException(){
		this.msg=("Fannie Exception Called...");
	}
	FannieException(String msg){
		this.msg=msg;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
	@Override
	// for printing an object this is needed
	public String toString() {
		// TODO Auto-generated method stub
		return ":::::" + this.msg +":::::::";
		
	}
	
	
}

class CitiExeption extends Exception {
	private String msg;
	
	CitiExeption(){
		msg="CITY exception called";
		
	}
	CitiExeption(String msg){
		this.msg=msg;
	}
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
	@Override
	// for printing an object this is needed
	public String toString() {
		// TODO Auto-generated method stub
		return ":::::" + this.msg +":::::::";
		
	}
}
public class UserException {

	public static void applyLoan(String loanType, int creditScore) throws CitiExeption, FannieException{
		
		
		if(loanType.equalsIgnoreCase("vehicle") && creditScore <400 ){
			throw new CitiExeption
			("Sorry your credit Score is less, vehicle loan not processed");
		}
		else if (loanType.equalsIgnoreCase("home")&& creditScore <700){
			throw new FannieException
			(" your Credit Score is low as per Fannie standards");
		} 
	}
	public static void main(String[] args) {
		try{
		applyLoan ("vehicle", 300);
		} catch (CitiExeption e) {
		e.printStackTrace();	
		} catch(FannieException fnm){
			fnm.printStackTrace();
		}
		
	}
}
