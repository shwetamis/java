package com.fannie.exception;

public class Account {
	
	private int accID;
	private double balance;
	private static int count=100;// everyone will use the same pool or starting value at class level
	
	
//constructors 
	public Account(double balance) {
		//super();
		//this.accID = accID;
		this.accID=count++;
		this.balance = balance;
	}
	
	// generate getter and setter
	public int getAccID() {
		return accID;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

}
