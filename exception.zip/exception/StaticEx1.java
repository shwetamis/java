package com.fannie.exception;

//public class StaticEx1 { /// in this case you need to create an object of this class which is StaticEx1 s= new StaticEx1()
 class Testing {
	 public static void testMe(){ // Although it is static but since out of the StaticEX1 class , class reference is needed to call its method
		 System.out.println("Test me");
	 }
 }




	public  class StaticEx1{
	public static int add( int a, int b) {
	return a+b;
}
	static {
		System.out.println(" hi i am static block"); // it can't be called explicitly , it is implicit
	}
	
	
	public static void hi(){
		System.out.println(" you called hi");
	}
	
/// static methods and var are class level, not at instance level
	public static void main(String[] args) {
		//StaticEx1 s= new StaticEx1();
		int x =add(22, 44);
		System.out.println(x);
		hi();
		hello();
		Testing.testMe();
		
	}
	public static void hello() {
		System.out.println(" You called hello");
	}
	
	static {
		System.out.println(" hi i am static block number 2"); // it can't be called explicitly , it is implicit and it comes first before main block
		//they get invoke by JVM implicitly, and this will sure shot get executed even if there is nothing in the main section of the block
	}
}
