package com.fannie.exception;

public class Exception1 {

	public static void main(String[] args) {
// using try catch block will not terminate the program in first unchecked exception
		try {
			int num1 = 10;
			int num2 = 0;
			
//nested exception
			try {
				int[] arr =new int[-4];
				arr[11]=3333;// this will call array index outbound index
				} catch (NegativeArraySizeException neg)
			      {
					System.out.println("NEGEXCP :" + neg);
			       }
			int result = num1 / num2;
			System.out.println(" Result is :" + result);
		} 
		
		// When creating exception hiearchy make sure specific exception class comes first  then comes generic classes
		//since i know its arethmetic exception i used this 
		catch (ArithmeticException ae){ // is its instance of arithmetic you catch it
			System.out.println("Arithemetic exception is invoke : " +ae);
		}
		
		catch(ArrayIndexOutOfBoundsException aio)
		{
			System.out.println("AIOBE :" + aio);
		}
		/*catch (NegativeArraySizeException neg)
		{
			System.out.println("NEGEXCPT :"+ neg);
		}*/
		catch (Exception e) { // if not catch here
			System.out.println(e);
		}

		System.out.println(" Some business logic goes here....");

	}
}
