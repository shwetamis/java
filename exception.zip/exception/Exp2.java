package com.fannie.exception;

public class Exp2 {
 public static void main(String[] args) {
	//try can also work with just finally if catch is removed 
	 try{
	 //int[] arr=new int[4];
		 return;
	 
	 } 
	 catch (RuntimeException re){
	 re.printStackTrace(); /// it tells which package it happens and line number and all the stck trace is displayed
	 } 
 finally {
		 System.out.println(" I am from finally..."); /// finally will always get executed, although catch didn't executed
	 }
	System.out.println("Some error");
 }
}
