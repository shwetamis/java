package com.fannie.exception;

public class Exp3 {

public static void checkName(String name) {
		if (name.length() < 4) {
			throw new RuntimeException(" Sorry name can't be less than 4");
		}
	}
public static void checkSal(int sal, String name) {

		// public static void main(String[] args) {
		try{
			checkName(name);// invoke check name  methods
		
		if (sal < 1000) {
			throw new ArithmeticException(" Sorry sal is less for : " + name + "given" + sal);
		}

		else {
			System.out.println("sal under process : " + name + "," + sal);
		}
	} catch (RuntimeException re){
		throw new 
		RuntimeException("sorry checking sal not done", re);
	 }	
	}

	public static void main(String[] args) {
		checkSal(100, "Pet");
	}
}
