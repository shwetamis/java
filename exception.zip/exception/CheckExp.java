package com.fannie.exception;
//Checked exception
import java.io.IOException;

public class CheckExp {
	public static void submitLoan(String loanType, String custName, int amount) throws IOException{
		if(amount<10000) {
			throw new IOException("String loan not " + "processed because of loan amount not applied");
			
		}
	}
public static void main(String[] args) { 
	try{
		submitLoan("HOME", "SCOTT", 200);
	} catch (IOException e) {
		e.printStackTrace();
	}
 }
	
}
