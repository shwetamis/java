package com.fannie.exception;

public class AccountClient {

	public static void main(String[] args) {
		
		Account[] acc = new Account[4];
		acc[0] = new Account (1000);
		acc[1] = new Account (1212);
		acc[2] = new Account (4321);
		acc[3] = new Account (32435);

		for  ( Account temp : acc) {
			System.out.println(temp.getAccID()+","+ temp.getBalance());
		}
	}
}
