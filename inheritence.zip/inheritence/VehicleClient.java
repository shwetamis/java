package com.fannie.inheritence;

public class VehicleClient {
	
	public static void main(String[] args) {
		//array 
		
		Vehicle [] vehicles = new Vehicle [5]; //5 block of memory created
		
		vehicles[0] =new Car ("BMW"," Red");
		vehicles[1] =new Jeep ("Audi",2);
		vehicles[2] =new Car ("Toyota"," Blue");
		vehicles[3] =new Jeep ("Audi",2);
		vehicles[4] =new Jeep ("Toyota",2);
		
		new VelicleBL().display(vehicles);
		
		/*//advance for loop ( for each loop
		for(Vehicle temp : vehicles){
			System.out.println("-------------------------");
			temp.move();
			((FourWheeler)temp).steering();
			
			//instance of operator :- Object instanceOF class		
			if(temp instanceof Car){
		System.out.println("Car make " + ((Car)temp).getMake());
			}
			else if (temp instanceof Jeep) {
				System.out.println("Jeep Doors :" + ((Jeep) temp).getDoors());
				System.out.println("Jeep Model :" + ((Jeep)temp).getModel());
				
			
			}
			
			//((Car)temp).getMake();-->//class cast exception since care casted with jeep so exception occurs
			
			
			//System.out.println();
			
		}
	
*/
  }
}
