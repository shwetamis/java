package com.fannie.inheritence;

public abstract  class FourWheeler extends Vehicle {
	//in a class if there is atleast 1 abstract method class should be made abstract
	public abstract void steering();
	
	//absrtract method can't hav a body
	
	// *{
		
		//System.out.println(" All four wheelers have steerings");
	//}

}
