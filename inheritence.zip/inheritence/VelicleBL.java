package com.fannie.inheritence;
//business logic is put in separate class and then called on vehicleclient
public class VelicleBL {
	
	public void display(Vehicle[] vehicles){
		for(Vehicle temp : vehicles){
			System.out.println("-------------------------");
			temp.move();
			((FourWheeler)temp).steering();
			
			//instance of operator :- Object instanceOF class		
			if(temp instanceof Car){
		System.out.println("Car make " + ((Car)temp).getModel()); 
				System.out.println("Car Color " +  ((Car)temp).getColor());
			}
			else if (temp instanceof Jeep) {
				System.out.println("Jeep Doors :" + ((Jeep) temp).getDoors());
				System.out.println("Jeep Model :" + ((Jeep)temp).getModel());
				
			
			}
			
		}
	
	}

}
