package com.fannie.inheritence;

public class Vehicle {

	public void move(){
		System.out.println(" All vehicles moves");
	}
}
