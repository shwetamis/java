package com.fannie.inheritence;

public class Car extends FourWheeler{
	private String model;
	private String color;
	//public void make(String model){
		//this.model= model;
	public Car( String model,String color){ //make class immutable when you invoke  a class u are setting new constructor
		this.model = model;
		this.color =color;
	}

public Car(String string, int i, boolean b) {
		// TODO Auto-generated constructor stub
	}

public Car(String model2, int i) {
	// TODO Auto-generated constructor stub
}

public String getModel() {
		return model;
	}

	public String getColor() {
		return color;
	}

@Override
public void steering() {
	// TODO Auto-generated method stub
	//super.steering();
	System.out.println(" BMW has power steering");
	
}
@Override
public void move() {
	// TODO Auto-generated method stub
	//super.move();
	System.out.println(" BMW MOVES");
}

 
}
