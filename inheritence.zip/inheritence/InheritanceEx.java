package com.fannie.inheritence;

class A{
	A(){
		super(); // is you don't write compiler will do it this we write when we need parameters.
	System.out.println(" HI i am from A");
	}
}
class B extends A{
	B(){
		super();
	System.out.println(" HI i am from B");
	}
}
class C extends B{
	C(){
		super();
	System.out.println(" HI i am from C");
	}
}

public class InheritanceEx {
 public static void main (String args[]){
	 
	 C objc = new C();
 }
 }
 
