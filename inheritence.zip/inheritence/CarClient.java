package com.fannie.inheritence;

public class CarClient {

	 public static void main(String[] args) {
		
		 /*Car bmw =new Car("BMW");
		
		 System.out.println(bmw.getMake());
		 // this will just inherit parents behavior  that we don't want
		 bmw.steering();
		 bmw.move();
		 
		 
		 Jeep audiJeep = new Jeep("AUDI", 2);
		 audiJeep.move();
		 audiJeep.steering();
		 System.out.println(audiJeep.getDoors());
		 System.out.println(audiJeep.getModel());
*/
		 
	}
}
