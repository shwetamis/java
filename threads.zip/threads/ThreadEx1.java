package com.fannie.threads;

//if you have main method then its a thread in the class
// to avoid aging class BusinessLogic should be extending
//class BusinessLogic
// by extending class thread you are eligible for asynchronous
class BusinessLogic extends Thread {
	public void run(){
		for (int i=0 ; i<500 ; i++) {
			System.out.println(" I value " + i + "  in Thread" +
					Thread.currentThread().getName());
		}
		
		System.out.println(" Thread" + currentThread().getName() + " Exiting");
	}
}

public class ThreadEx1 {
	//1 is min
	//5 is norm ( default)
	// 10 is max priority

	public static void main(String[] args) {
		
		System.out.println("Name :" + Thread.currentThread().getName());
		System.out.println("Priority" + Thread.currentThread().getPriority());
		
		//new BusinessLogic().doMyJob(); // invoking method to do my job  ---> remove this and then have new Business logic to avoid aging.
		// when you make a request for start() then OS level thread is create and control given to special method called public void run (){},
		//thus asynchronous , it is not predicted
		BusinessLogic bl  = new BusinessLogic();
		bl.setName("My Thread A");
		bl.setPriority(3);
		bl.start();
		
		// Priority also don't guarantee that thread will be executed first in the eco-system, as system build time is  more  than system processing time, so by the time we 
		// set priority it already finished the process.
		BusinessLogic b2 = new BusinessLogic(); // new thread created
		b2.setName("My Thread B");
		bl.setPriority(10);
		b2.start();
		
		
		// simulate some time killing in the system
		for (int i=0 ; i<500 ; i++) {
			System.out.println(" I value " + i + "  in Thread " +
					Thread.currentThread().getName());
		}
		
		try {
			bl.join(); // you get 3 overloaded method call, join  ( long milli ) with milli sec i will wait for you milli sec
			// throws exception that means some one interrupted add TRY Catch block
			b2.join(); 
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(" Main Exiting");
	}
}
