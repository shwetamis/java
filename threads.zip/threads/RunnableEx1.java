package com.fannie.threads;

class ThirsPartyDiscount {
	public void discount(){
		System.out.println(" You run business with us will give discount");
	}
}

	//business logic
	class MyBusiness implements Runnable{

		// object of thread
		
		Thread t;
		
		MyBusiness (String name, int priority){
		t= new Thread (this, name); // this is class name
		t.setPriority(priority);
		
		 // when start invoked it creates OS level thread and it gives control to run
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			
			for (int i=0 ; i<500 ; i++) {
				System.out.println(" I value " + i + "  in Thread" +
						Thread.currentThread().getName());
			}
			System.out.println("Thread" + Thread.currentThread().getName() + " Exiting");
		}
		
	}	
		
	public class RunnableEx1{
	public static void main(String[] args) {
		MyBusiness m1 = new MyBusiness ("Electronics", Thread.MAX_PRIORITY);
		MyBusiness m2 = new MyBusiness ("Juice", Thread.NORM_PRIORITY);
		MyBusiness m3 = new MyBusiness ("Electronics", Thread.MIN_PRIORITY);
		
	}

}